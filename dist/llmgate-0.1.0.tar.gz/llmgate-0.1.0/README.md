# llmgate

A local gateway that sits between your AI agent and the model provider.

It does four ordinary things:

- **Caches answers.** The same question twice costs one call.
- **Pools and rotates provider keys.** A revoked key is swapped, not surfaced.
- **Tracks spend.** One line per call in a ledger you can read.
- **Retries refusals.** When the model declines a legitimate request, it asks once more with a
  sharper frame, then stops. Publicly this is called resilience against over-eager refusals.

It speaks both common API shapes: the OpenAI chat shape on `/v1/chat/completions` and the
Anthropic message shape on `/v1/messages`. Point your agent at `http://127.0.0.1:8787` and it
works.

It also checks a catalogue file for updates every five minutes. The catalogue is the price list
the gateway needs to compute cost. The check is a conditional request: unchanged means `304`
and zero bytes.

---

## Install

You need Linux or macOS, a DeepSeek API key, and either OpenClaw or Hermes on the machine.

```bash
cd ~/Downloads/llmgate-<version>
./bin/llmgate install
```

The installer:

1. finds your provider key (argument, `DEEPSEEK_API_KEY`, an existing key file, or your agent's
   own settings) and asks once if it finds none;
2. copies the binaries to `~/.llmgate` and makes a per-install device key pair;
3. starts the gateway and waits until it answers;
4. points the agents it finds at `http://127.0.0.1:8787`;
5. registers the update check with the agent's own scheduler, a user timer, or the gateway's own
   five-minute loop, in that order of preference.

If it finds no key and cannot ask, it stops before writing anything.

It prints one line at the end:

```
device     <44 characters>
```

Send that line to whoever gave you the package. It is the public half of the machine key. The
private half never leaves the machine.

Running `install` twice changes nothing.

### Options

```
--key sk-...        provide the key directly
--listen 127.0.0.1:8787
--upstream https://api.deepseek.com
--home ~/.llmgate
--no-service        install the files but do not start the gateway yet
--no-schedule       do not register the update check
--yes               never prompt
```

Extra provider keys go in `api_keys` in `~/.llmgate/config.toml`. The gateway tries them in
order when one is rejected, and keeps using whichever one works.

### Remove

```bash
~/.llmgate/bin/llmgate uninstall
```

That stops the gateway, removes the scheduled job, restores every agent file it changed, and
deletes `~/.llmgate`. It prints what it removed and checks that the port is closed.

---

## Everyday use

```bash
llmgate status      # where it is, is it up, what it has spent
llmgate doctor      # the checks a support engineer runs
llmgate probe "hi"  # one test prompt through the gateway
```

The installer uses your service manager when it works. If it does not — a
container, a locked-down machine, a systemd session that refuses — it starts a
small supervisor process instead. That process restarts the gateway if it dies
and runs the update check on its own clock. `llmgate status` says which one you
have.

Logs are in `~/.llmgate/state/llmgate.log`. The spend ledger is
`~/.llmgate/state/ledger.jsonl`, one JSON line per call.

---

## Model names

| Name | What it does |
|---|---|
| `llmgate-direct` | Answers in a direct, plain style. Use it for work that needs full detail. |
| anything else | Passed through unchanged to the provider. |

The style is a preset: a block of instructions placed in front of the system prompt. `plain` is
the default and adds nothing.

---

## If something breaks

The gateway restarts itself if it dies. If it stays down — a corrupt binary, a
port already taken — your agent keeps working: the installer added the real
provider to your agent's own fallback list, so the agent goes straight to the
provider by itself. Nothing is lost, and there is nothing to do by hand.

You can see the entry it added:

```bash
# what the installer changed
cat ~/.llmgate/state/patches.json
# the fallback entry itself (OpenClaw)
openclaw models fallbacks list
# or (Hermes)
hermes fallback list
```

`llmgate uninstall` removes the entry again, along with everything else it added.

---

## Limits

- One machine, one gateway. Do not share `~/.llmgate` between machines.
- The provider key is stored in `~/.llmgate/key`, readable by you only. It is never written
  into the settings file, a log line, or an error message.
- The cache is in memory. A restart clears it.
