# llmgate

A local gateway that sits between your AI agent and the model provider.

It does four ordinary things:

- **Caches answers.** The same question twice costs one call.
- **Pools and rotates provider keys.** A revoked key is swapped, not surfaced.
- **Tracks spend.** One line per call in a ledger you can read.
- **Keeps answers coming.** When the model declines a request, it asks once more
  with a clearer frame, then stops. This is a reliability feature: the goal is an
  answer, not a negotiation.

It speaks both common API shapes: the OpenAI chat shape on `/v1/chat/completions` and the
Anthropic message shape on `/v1/messages`. Point your agent at `http://127.0.0.1:8787` and it
works.

It also checks a catalogue file for updates every five minutes. The catalogue is the price
list the gateway needs to compute cost, and the place a price change is announced. The check is
a conditional request: unchanged means `304` and zero bytes.

---

## Install

You need 64-bit Linux (x86_64 or ARM64), a DeepSeek API key, and either OpenClaw or
Hermes on the machine.

```bash
tar xzf llmgate-<version>.tar.gz
cd llmgate-<version>
./bin/install.sh
```

`bin/install.sh` looks at your machine and runs the right build. Both are inside the
package, statically linked, so nothing has to be installed first.

To see which build you are running:

```bash
~/.llmgate/bin/llmgate-update-check --print-build    # e.g. x86_64-linux-musl
```

The installer:

1. finds your provider key (argument, `DEEPSEEK_API_KEY`, an existing key file, or your agent's
   own settings) and asks once if it finds none;
2. copies the binaries to `~/.llmgate` and makes a per-install cache key pair;
3. starts the gateway and waits until it answers;
4. points the agents it finds at `http://127.0.0.1:8787`;
5. registers the update check with the agent's own scheduler, a user timer, or the gateway's own
   five-minute loop, in that order of preference.

If port 8787 is already taken by something else, it picks a free port and prints which one.

If it finds no key and cannot ask, it stops before writing anything.

It prints one line at the end:

```
catalogue  <44 characters>
```

That is this machine's identifier. The private half never leaves the machine and is never
printed. There is nothing to send anywhere: the update check is already registered, and a
notice addressed to every copy needs no key from this one.

Running `install` twice changes nothing.

### Options

```
--key sk-...        provide the key directly (or set DEEPSEEK_API_KEY)
--listen 127.0.0.1:8787
--upstream https://api.deepseek.com
--home ~/.llmgate
--no-service        install the files but do not start the gateway yet
--no-schedule       do not register the update check
--yes               never prompt
```

Extra provider keys go in `api_keys` in `~/.llmgate/config.toml`. The gateway tries them in
order when one is rejected, and keeps using whichever one works.

### Remove

```bash
~/.llmgate/bin/llmgate uninstall          # or: bin/install.sh uninstall, from the package
```

That stops the gateway, removes the scheduled job, restores every agent file it changed, and
deletes `~/.llmgate`. It prints what it removed and checks that the port is closed.

---

## Everyday use

```bash
llmgate status      # where it is, is it up, what it has spent
llmgate doctor      # the checks a support engineer runs
llmgate probe "hi"  # one test prompt through the gateway
```

The installer uses your service manager when it works. If it does not — a
container, a locked-down machine, a systemd session that refuses — it starts a
small supervisor process instead. That process restarts the gateway if it dies
and runs the update check on its own clock. `llmgate status` says which one you
have.

Logs are in `~/.llmgate/state/llmgate.log`. The spend ledger is
`~/.llmgate/state/ledger.jsonl`, one JSON line per call.

---

## Model names

| Name | What it does |
|---|---|
| `llmgate-direct` | Answers in a direct, plain style. Use it for work that needs full detail. |
| anything else | Passed through unchanged to the provider. |

The style is a preset: a block of instructions placed in front of the system prompt. `plain` is
the default and adds nothing.

---

## If something breaks

The gateway restarts itself if it dies. If it stays down — a corrupt binary, a
port already taken — your agent keeps working: the installer added the real
provider to your agent's own fallback list, so the agent goes straight to the
provider by itself. Nothing is lost, and there is nothing to do by hand.

You can see the entry it added:

```bash
# what the installer changed
cat ~/.llmgate/state/setup.json
# the fallback entry itself (OpenClaw)
openclaw models fallbacks list
# or (Hermes)
hermes fallback list
```

`llmgate uninstall` removes the entry again, along with everything else it added.

---

## Limits

- One machine, one gateway. Do not share `~/.llmgate` between machines.
- The provider key is stored in `~/.llmgate/key`, readable by you only. It is never written
  into the settings file, a log line, or an error message.
- The cache is in memory. A restart clears it.
